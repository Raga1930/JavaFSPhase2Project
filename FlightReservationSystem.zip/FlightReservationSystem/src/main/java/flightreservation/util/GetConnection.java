package flightreservation.util;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

public interface GetConnection {
public SessionFactory getConnected();

}
